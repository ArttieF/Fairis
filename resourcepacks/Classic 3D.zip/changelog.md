v13.3.1

Changes:

Textures are no longer removed

---

Fixed:

[Dirt Path is missing textures](https://github.com/RyanGar46/Classic-3D/issues/3 "#3")

Poppy and Wither Rose had texture issues

---

Links:

To report a bug or give feedback, go here:

[Classic 3D's Github](github.com/RyanGar46/Classic-3D/issues "Github")

To get news and updates about the Classic 3D, go here:

[Classic 3D's Twitter](twitter.com/Classic_3D "Twitter")

---

Credit:

Some textures by:

[GodAmongDessert](instagram.com/godamongdessert/ "Instagram")

The only official download websites for Classic 3D are [CurseForge](https://www.curseforge.com/minecraft/texture-packs/classic-3d "CurseForge") and [Planet Minecraft](https://www.planetminecraft.com/texture-pack/classic-3d-4384051/ "Planet Minecraft"). Don't download it from any other website.
